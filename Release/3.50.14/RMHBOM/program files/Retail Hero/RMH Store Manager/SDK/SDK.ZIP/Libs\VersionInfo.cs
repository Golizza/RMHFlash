﻿using System.Reflection;

[assembly: AssemblyCompany("Retail Management Hero")]
[assembly: AssemblyCopyright("Copyright Retail Management Hero ©  2015-2021")]
[assembly: AssemblyTrademark("Retail Management Hero (tm)")]

[assembly: AssemblyVersion("3.50.14.34820")]
[assembly: AssemblyFileVersion("3.50.14.34820")]
[assembly: AssemblyInformationalVersion("3.50.14.34820")]
