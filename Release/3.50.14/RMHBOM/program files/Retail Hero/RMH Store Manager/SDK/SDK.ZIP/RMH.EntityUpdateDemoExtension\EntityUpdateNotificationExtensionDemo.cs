﻿using RMH.APP.Core.Shared;
using RMH.APP.Core.Shared.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.EntityUpdateNotifictionExtensionDemo
{ 
    [Export(typeof(IRMHCustomExtension))]
    public class EntityUpdateNotificationExtensionDemo: IRMHCustomExtension
    {

        public ApplicationSession AppSession { get; set; }

        public EntityUpdateNotificationExtensionDemo()
        {
            ServiceProvider service = ServiceProvider.Instance;

            AppSession =(ApplicationSession) service.GetObject(typeof(ApplicationSession));

            //register for getting notifications when customer object is updated
            AppSession.onCustomerSavedBefore += AppSession_onCustomerSavedBefore;
            AppSession.onCustomerSavedAfter += AppSession_onCustomerSaved;

            //register for getting notificatios when ITEM object is updated
            AppSession.onItemSavedBefore += AppSession_onItemSavedBefore;
            AppSession.onItemSavedAfter += AppSession_onItemSaved;

            //register for getting notification when Order object is saved
            AppSession.onOrderSavedBefore += AppSession_onOrderSavedBefore;
            AppSession.onOrderSavedAfter += AppSession_onOrderSaved;

            //register for getting notifications when closed batches are posted
            AppSession.onCompletedPostingClosedBatches += AppSession_onCompletedPostingClosedBatches;

            //register for getting notifications when reason codes are saved
            AppSession.onReasonCodeSavedBefore += AppSession_onReasonCodeSavedBefore;
            AppSession.onReasonCodeSavedAfter += AppSession_onReasonCodeSavedAfter;
            
        }

        private void AppSession_onReasonCodeSavedBefore(IReasonCode arg1, System.ComponentModel.CancelEventArgs arg2)
        {
            //throw new NotImplementedException();
        }

        private void AppSession_onReasonCodeSavedAfter(IReasonCode obj)
        {
           // throw new NotImplementedException();
        }

        private void AppSession_onOrderSavedBefore(IPurchaseOrder arg1, System.ComponentModel.CancelEventArgs arg2)
        {
           
        }

        private void AppSession_onItemSavedBefore(IItemModel arg1, System.ComponentModel.CancelEventArgs arg2)
        {
           
        }

        private void AppSession_onCompletedPostingClosedBatches(IBatchModel[] arg1, string arg2)
        {
            
        }

        private void AppSession_onCustomerSavedBefore(ICustomer arg1, System.ComponentModel.CancelEventArgs arg2)
        {
            //TEST
          //  arg2.Cancel = true;
            //throw new NotImplementedException();
        }

        private void AppSession_onOrderSaved(IPurchaseOrder obj)
        {
            //throw new NotImplementedException();
        }

        private void AppSession_onItemSaved(IItemModel obj)
        {
           // throw new NotImplementedException();
        }

        private void AppSession_onCustomerSaved(ICustomer obj)
        {
           // throw new NotImplementedException();
        }
     
    }
}
