﻿using RMH.APP.Core.Shared.Contracts;
using System;
using System.Collections.Generic;

namespace RMHDemoStoreSyncItems.Models
{
    class Customer : ICustomer
    {
        public string AccountNumber { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string Company { get; set; }
        public double CurrentDiscount { get; set; }
        public string EmailAddress { get; set; }
        public bool Employee { get; set; }
        public string FirstName { get; set; }
        public int ID { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public int AccountTypeID { get; set; }
        public bool AssessFinanceCharges { get; set; }
        public string Country { get; set; }
        public DateTime? CustomDate1 { get; set; }
        public DateTime? CustomDate2 { get; set; }
        public DateTime? CustomDate3 { get; set; }
        public DateTime? CustomDate4 { get; set; }
        public DateTime? CustomDate5 { get; set; }
        public double CustomNumber1 { get; set; }
        public double CustomNumber2 { get; set; }
        public double CustomNumber3 { get; set; }
        public double CustomNumber4 { get; set; }
        public double CustomNumber5 { get; set; }
        public string CustomText1 { get; set; }
        public string CustomText2 { get; set; }
        public string CustomText3 { get; set; }
        public string CustomText4 { get; set; }
        public string CustomText5 { get; set; }
        public bool GlobalCustomer { get; set; }
        public int HQID { get; set; }
        public DateTime? LastStartingDate { get; set; }
        public DateTime? LastClosingDate { get; set; }
        public DateTime? LastUpdated { get; set; }
        public bool LimitPurchase { get; set; }
        public decimal LastClosingBalance { get; set; }
        public int PrimaryShipToID { get; set; }
        public int StoreID { get; set; }
        public bool LayawayCustomer { get; set; }
        public decimal AccountBalance { get; set; }
        public decimal CreditLimit { get; set; }
        public DateTime? AccountOpened { get; set; }
        public DateTime? LastVisit { get; set; }
        public int TotalVisits { get; set; }
        public decimal TotalSavings { get; set; }
        public int PriceLevel { get; set; }
        public bool TaxExempt { get; set; }
        public string Notes { get; set; }
        public string Title { get; set; }
        public string TaxNumber { get; set; }
        public string PictureName { get; set; }
        public int DefaultShippingServiceID { get; set; }
        public string FaxNumber { get; set; }
        public int CashierID { get; set; }
        public int SalesRepID { get; set; }
        public decimal Vouchers { get; set; }
        public string SyncGuid { get; set; }

        public IEnumerable<IShippingAddress> ShippingAddresses { get; set; }

        public IEnumerable<ICustomerAlias> Aliases { get; set; }
    }
}
