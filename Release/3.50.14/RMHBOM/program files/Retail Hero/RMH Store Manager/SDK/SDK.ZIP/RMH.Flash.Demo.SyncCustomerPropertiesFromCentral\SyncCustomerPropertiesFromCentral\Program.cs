﻿using RMH.Central.Communication.Generators;
using RMH.Central.FlashBridge.Arguments;
using RMH.Central.FlashBridge.Components;
using RMH.Communication.Core.Models;
using RMH.Communication.Core.Models.Enums;
using RMHDemoStoreSyncItems.Models;
using System;
using System.Configuration;
using System.IO;

namespace RMHDemoStoreSyncItems
{
    internal class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            // 1. Load settings (as: rule file, storeId, connection string) and generate sample 'Customer' record.      
            string connectionStringValue = ConfigurationManager.AppSettings["ConnectionString"];
            int.TryParse(ConfigurationManager.AppSettings["StoreId"], out int storeId);
            // initialize FBA for Central
            RMHFlashBridge.Instance.Initialize(new RMHFlashBridgeInitArgument()
            {
                ConnectionString = connectionStringValue,
                StoreID = 0
            });

            // 2. Request update Cusstomer to Store via FBA
            using (RMHCClientJobGenerator generator = new RMHCClientJobGenerator())
            {
                // create store destination
                Destination destination = new Destination(storeId);
                // create 'job' business object base on 'Customer'
                Customer sampledata = new Customer();
                sampledata.SyncGuid = ConfigurationManager.AppSettings["CustomerSyncGuid"];
                sampledata.Company = "Company test 99";
                sampledata.Country = "Country test 99";
                string ruleFilePaths = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RuleFiles\\Customer.xml");
                BusinessObject bo = generator.GenerateJob(ruleFilePaths, JobOperation.Update, destination, sampledata);

                // send 'job' business object to the Store
                RMHFlashBridge.Instance.AddJobToHolderSync(bo, destination);
            }
        }
    }      
}
