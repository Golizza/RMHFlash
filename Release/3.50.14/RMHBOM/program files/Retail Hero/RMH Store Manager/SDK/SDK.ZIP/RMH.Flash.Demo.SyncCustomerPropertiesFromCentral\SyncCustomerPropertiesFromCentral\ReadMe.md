# RMH.Flash.Demo.SyncCustomerPropertiesFromCentral.SyncCustomerPropertiesFromCentral

The 'SyncCustomerPropertiesFromCentral' project (net framework 4.6.1) is a console program that creates sample Customer and sends them from RMHC Central to RMMC Store via the RMH Flash Bridge job.

## Installation
1. Update the settings in App.config:
    - `ConnectionString`: Connection string to the Store database.
    - `StoreId`: The ID of the store.
    - `CustomerSyncGuid`: The SyncGuid of the customer that exists in the Central DB. You can use the query below to select the GUID:
          SELECT SyncGuid, * FROM customer 

## Usage	
1. Run the 'SyncCustomerPropertiesFromCentral' project; it will create a 'Job' and send it to RMH Flash Bridge.
2. Check the update 'Customer' in Store by following query:
          SELECT * FROM customer WHERE SyncGuid = `CustomerSyncGuid`
