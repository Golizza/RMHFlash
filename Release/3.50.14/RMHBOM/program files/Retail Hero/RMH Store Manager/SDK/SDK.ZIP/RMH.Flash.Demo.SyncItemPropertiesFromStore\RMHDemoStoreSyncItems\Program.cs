﻿using RetailHero.POS.Core.Shared.Helpers;
using RMH.Central.Communication.Generators;
using RMH.Central.FlashBridge.Arguments;
using RMH.Central.FlashBridge.Components;
using RMH.Communication.Core.Models;
using RMH.Communication.Core.Models.Enums;
using RMHDemoStoreSyncItems.Models;
using System;
using System.Configuration;
using System.IO;

namespace RMHDemoStoreSyncItems
{
    internal class Program
    {    
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            // 1. Load settings (storeId, connection string) and generate sample 'Item' record.          
            int.TryParse(ConfigurationManager.AppSettings["StoreId"], out int storeId);
            string connectionStringValue = RHSettingsBase.GetPrimaryConnectionString();
            // initialize FBA for Store
            RMHFlashBridgeInitArgument arg = new RMHFlashBridgeInitArgument()
            {
                ConnectionString = connectionStringValue,
                StoreID = storeId
            };
            // 2. Request update Item to Central via FBA         
            using (RMHCClientJobGenerator generator = new RMHCClientJobGenerator())
            {
                // create 'job' business object to update Item
                Item sampleItem = new Item();
                sampleItem.SyncGuid = ConfigurationManager.AppSettings["ItemSyncGuid"];
                sampleItem.Quantity = 666;
                sampleItem.Price = 66.66m;
                sampleItem.Cost = 33.33m;            
                string ruleFileUpdateItem = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RuleFiles\\Item.xml");
                BusinessObject bo = generator.GenerateJob(ruleFileUpdateItem, JobOperation.Update,
                    new Destination(storeId), sampleItem);      
                RMHFlashBridge.Instance.Initialize(arg);
                // send 'job' business object to the central
                RMHFlashBridge.Instance.AddJobToHolderSync(bo, Destination.Central);
            }
        }      
    }
}
