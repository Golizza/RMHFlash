# RMH.Flash.Demo.SyncItemPropertiesFromStore.RMHDemoStoreSyncItems

The 'RMHDemoStoreSyncItems' project (net framework 4.6.1) is a console program that creates sample Items and sends them to RMHC Central via the RMH Flash Bridge job.

## Installation
1. Update the settings in App.config:
    - `StoreId`: The ID of the store.
    - `ItemSyncGuid`: The SyncGuid of the item that exists in the Central DB. You can use the query below to select the GUID:
            SELECT id.ItemID, i.SyncGuid, id.*
            FROM [dbo].[Item] i
            INNER JOIN [dbo].[ItemDynamic] id ON i.ID = id.ItemID
            WHERE STOREID = `StoreId` 

## Usage	
1. Run the 'RMHDemoStoreSyncItems' project; it will create a 'Job' and send it to RMH Flash Bridge.
2. Check the update 'Item' in Central by following query:
            SELECT ID, Price, Cost, Quantity, * FROM ItemDynamic  
            WHERE ItemID = (SELECT TOP (1) [ID] FROM [Item] WITH (NOLOCK) WHERE [SyncGuid] = `ItemSyncGuid`)