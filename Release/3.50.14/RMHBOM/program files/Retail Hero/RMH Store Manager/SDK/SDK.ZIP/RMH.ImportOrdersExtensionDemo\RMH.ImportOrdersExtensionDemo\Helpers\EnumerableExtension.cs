﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RMH.ImportOrdersExtensionDemo.Helpers
{
    public static class EnumerableExtension
    {
        public static DataSet ToDataSet<T>(this IEnumerable<T> list)
        {
            var elementType = typeof(T);
            var ds = new DataSet();
            string tableName = elementType.Name;
            if (elementType.Name.EndsWith("Model"))
                tableName = elementType.Name.Substring(0, elementType.Name.LastIndexOf("Model"));

            var t = new DataTable(tableName);
            ds.Tables.Add(t);

            var properties =
                elementType.GetProperties().Select((pi, i) =>
                {
                    var attr = pi.GetCustomAttribute(typeof(DisplayAttribute), true) as DisplayAttribute;
                    var order = attr?.Order ?? i + 1000;
                    return Tuple.Create(order, pi);
                })
                .OrderBy(tpl => tpl.Item1)
                .Select(tpl => tpl.Item2)
                .ToArray();

            //add a column to table for each public property on T
            foreach (var propInfo in properties)
            {
                var ColType = Nullable.GetUnderlyingType(propInfo.PropertyType) ?? propInfo.PropertyType;

                t.Columns.Add(propInfo.Name, ColType);
            }

            //go through each property on T and add each value to the table
            foreach (T item in list)
            {
                DataRow row = t.NewRow();

                foreach (var propInfo in elementType.GetProperties())
                {
                    row[propInfo.Name] = propInfo.GetValue(item, null) ?? DBNull.Value;
                }

                t.Rows.Add(row);
            }

            return ds;
        }

    }
}
