﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.ImportOrdersExtensionDemo.Models
{
    public class PurchaseOrderEntryModel
    {
        public string ItemDescription { get; set; } = String.Empty;
        public DateTime LastUpdated { get; set; } = DateTime.Now;
        public float QuantityReceivedToDate { get; set; }
        public int StoreID { get; set; }
        public int ID { get; set; }
        public int PurchaseOrderID { get; set; }
        public float QuantityOrdered { get; set; }
        public float QuantityReceived { get; set; }
        public int ItemID { get; set; }
        public string OrderNumber { get; set; } = String.Empty;
        public decimal Price { get; set; }
        public float TaxRate { get; set; }
        public int InventoryOfflineID { get; set; }
        public decimal ShippingPerItem { get; set; }
        public decimal OtherFeesPerItem { get; set; }
        public float LastQuantityReceived { get; set; }
        public DateTime? LastReceivedDate { get; set; }
    }

    public class POD_OrderEntryModel
    {
        public int ID { get; set; }
        public int StoreID { get; set; }
        public int LinkID { get; set; }
        public int RmsID { get; set; }
        public DateTime LastUpdated { get; set; } = DateTime.Now;
        public int OrderID { get; set; }
        public int LineType { get; set; }
        public int LineNumber { get; set; }
        public int EntryType { get; set; }
        public int EntryID { get; set; }
        public int ItemTaxID { get; set; }
        public string OrderNumber { get; set; } = String.Empty;
        public string Description { get; set; } = String.Empty;
        public int UOMID { get; set; }
        public float Quantity { get; set; }
        public float QtyReceived { get; set; }
        public float QtyToReceive { get; set; }
        public float QtyInvoiced { get; set; }
        public float QtyToInvoice { get; set; }
        public float QtyPerUOM { get; set; }
        public decimal UnitCost { get; set; }
        public float LineDiscRate { get; set; }
        public float TaxRate { get; set; }
        public int LinkedEntryID { get; set; }
        public int ParentEntryID { get; set; }
        public int InventoryOfflineID { get; set; }
        public string Comment { get; set; } = String.Empty;
        public byte BIDPrice { get; set; }
    }
}
