﻿using RMH.ImportOrdersExtensionDemo.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.ImportOrdersExtensionDemo.Models
{
    public class PurchaseOrderModel
    {
        public DateTime LastUpdated { get; set; } = DateTime.Now;
        public string POTitle { get; set; } = String.Empty;
        public int POType { get; set; }
        public int StoreID { get; set; }
        public int WorksheetID { get; set; }
        public int ID { get; set; }
        public string PONumber { get; set; } = String.Empty;
        public short Status { get; set; }
        public DateTime DateCreated { get; set; } = DateTime.Now;
        public string To { get; set; } = String.Empty;
        public string ShipTo { get; set; } = String.Empty;
        public string Requisitioner { get; set; } = String.Empty;
        public string ShipVia { get; set; } = String.Empty;
        public string FOBPoint { get; set; } = String.Empty;
        public string Terms { get; set; } = String.Empty;
        public double TaxRate { get; set; }
        public decimal Shipping { get; set; }
        public string Freight { get; set; } = String.Empty;
        public DateTime? RequiredDate { get; set; }
        public string ConfirmingTo { get; set; } = String.Empty;
        public string Remarks { get; set; } = String.Empty;
        public int SupplierID { get; set; }
        public int OtherStoreID { get; set; }
        public int CurrencyID { get; set; }
        public float ExchangeRate { get; set; }
        public int OtherPOID { get; set; }
        public int InventoryLocation { get; set; }
        public byte IsPlaced { get; set; } = 0;
        public DateTime? DatePlaced { get; set; }
        public int BatchNumber { get; set; }
        public decimal EstShipping { get; set; }
        public decimal CurrentShipping { get; set; }
        public decimal EstOtherFees { get; set; }
        public decimal CurrentOtherFees { get; set; }
        public decimal OtherFees { get; set; }
        public int CostDistributionMethod { get; set; }
        public int ParentPOId { get; set; }
        public int RootPOId { get; set; }
        public int OriginPOId { get; set; }
        public string MasterPO { get; set; } = String.Empty;
        public int DiscrepancyStatus { get; set; }

        /// <summary>
        /// Payment Term ID
        /// </summary>
        public int PayTermID { get; set; }

        /// <summary>
        /// Ship Via
        /// </summary>
        public int ShipViaID { get; set; }

        /// <summary>
        /// Purchaser
        /// </summary>
        public int PurchaserID { get; set; }

        [TableName("PurchaseOrderEntry")]
        public List<PurchaseOrderEntryModel> Entries { get; set; }
    }

    public class POD_OrderModel
    {
        public int ID { get; set; }
        public int StoreID { get; set; }
        public int LinkID { get; set; }
        public int RmsID { get; set; }
        public DateTime LastUpdated { get; set; } = DateTime.Now;
        public int DocType { get; set; }
        public int DocSource { get; set; }
        public int DocOption { get; set; }
        public string Number { get; set; } = String.Empty;
        public int Status { get; set; }
        public int DelStatus { get; set; }
        public int InvStatus { get; set; }
        public int AllocationID { get; set; }
        public int SupplierID { get; set; }
        public int SupplierTaxID { get; set; }
        public DateTime DateCreated { get; set; } = DateTime.Now;
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public DateTime RequiredDate { get; set; } = DateTime.Now;
        public DateTime? DatePlaced { get; set; }
        public int LocationType { get; set; }
        public int LocationID { get; set; }
        public string Reference { get; set; } = String.Empty;
        public string AddrTo { get; set; } = String.Empty;
        public string ShipTo { get; set; } = String.Empty;
        public int PurchaserID { get; set; }
        public string Requisitioner { get; set; } = String.Empty;
        public int ShipViaID { get; set; }
        public string FOBPoint { get; set; } = String.Empty;
        public string Freight { get; set; } = String.Empty;
        public int PayTermID { get; set; }
        public int CurrencyID { get; set; }
        public float ExchangeRate { get; set; }
        public int InvDiscMode { get; set; }
        public float InvDiscValue { get; set; }
        public string Comment { get; set; } = String.Empty;
        public string ExternalDocNo { get; set; } = String.Empty;
        public string SupplierDocNo { get; set; } = String.Empty;
        public string SupplierDelNo { get; set; } = String.Empty;
        public DateTime? SupplierDelDate { get; set; }
        public string SupplierInvNo { get; set; } = String.Empty;
        public DateTime? SupplierInvDate { get; set; }
        public decimal SupplierInvAmt { get; set; }
        public string PostingComment { get; set; } = String.Empty;
        public decimal TotalAmount { get; set; }
        public decimal TotalTax { get; set; }
        public int PoType { get; set; }

        public List<POD_OrderEntryModel> Entries { get; set; }
    }
}
