﻿using Newtonsoft.Json;
using RetailHero.POS.Core.Shared;
using RetailHero.POS.Core.Shared.Helpers;
using RMH.ImportOrdersExtensionDemo.Helpers;
using RMH.ImportOrdersExtensionDemo.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace ImportOrdersExtensionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // only working parameter with input is a json file
            if (args.Length < 1)
            {
                Program.PrintError("The syntax of the command is incorrect.\nIt must be ImportOrdersExtensionDemo <json file path>");
            }

            List<PurchaseOrderModel> purchaseOrderList = new List<PurchaseOrderModel>();

            try
            {
                // read from file and parse/deserializer to model
                string textFile = args[0];
                string json = File.ReadAllText(textFile);
                purchaseOrderList = JsonConvert.DeserializeObject<List<PurchaseOrderModel>>(json);
            }
            catch (Exception ex)
            {
                Program.PrintError("Error on read or parse/deserializer :" + ex.ToString());
            }

            // load config from Setting RMH file 
            RHSettings.LoadConfig();
            string rmhposConnectionString = RHSettings.ConnectionString;

            #region mock for quick test
            ////List<PurchaseOrderModel> pos = new List<PurchaseOrderModel>()
            ////{
            ////       new PurchaseOrderModel(){ PONumber="PO123",StoreID=1,SupplierID=1, DateCreated=DateTime.Now,DatePlaced=DateTime.Now, ID=1 },
            ////       new PurchaseOrderModel(){ PONumber="PO1234",StoreID=1,SupplierID=3, DateCreated=DateTime.Now,DatePlaced=DateTime.Now, ID=2 },
            ////       new PurchaseOrderModel(){ PONumber="PO111",StoreID=1,SupplierID=11, DateCreated=DateTime.Now,DatePlaced=DateTime.Now, ID=3 }
            ////};
            ////pos[0].Entries = new List<PurchaseOrderEntryModel>()
            ////{
            ////    new PurchaseOrderEntryModel(){ ItemID=1,ItemDescription="RC/Glider",Price=100.0m,QuantityOrdered=5,StoreID=1, PurchaseOrderID=1},
            ////    new PurchaseOrderEntryModel(){ ItemID=2,ItemDescription="RC Train",Price=25.25m,QuantityOrdered=10,StoreID=1, PurchaseOrderID=1},
            ////    new PurchaseOrderEntryModel(){ ItemID=3,ItemDescription="Football",Price=156.30m,QuantityOrdered=15,StoreID=1, PurchaseOrderID=1}
            ////};

            ////pos[1].Entries = new List<PurchaseOrderEntryModel>()
            ////{
            ////    new PurchaseOrderEntryModel(){ ItemID=10,ItemDescription="Basketball",Price=100.0m,QuantityOrdered=5,StoreID=1, PurchaseOrderID=2},
            ////    new PurchaseOrderEntryModel(){ ItemID=12,ItemDescription="Lollypop",Price=25.25m,QuantityOrdered=50,StoreID=1, PurchaseOrderID=2},
            ////    new PurchaseOrderEntryModel(){ ItemID=13,ItemDescription="baby cycle",Price=156.30m,QuantityOrdered=1,StoreID=1, PurchaseOrderID=2}
            ////};
            #endregion

            // only import if json file has data
            if (purchaseOrderList.Any())
            {
                try
                {
                    // Import PO/TO
                    ImportOrders(connectionString: rmhposConnectionString, purchaseOrderList: purchaseOrderList);

                    Console.WriteLine("Import Order Successfully.");
                }
                catch (Exception ex)
                {
                    Program.PrintError("Error on importing Order :" + ex.ToString());
                }
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        #region Methods
        /// <summary>
        /// Imports orders to default RMH configured database that already used RHSetting
        /// </summary>
        /// <param name="purchaseOrderList"></param>
        /// <returns></returns>
        public static void ImportOrders(IEnumerable<PurchaseOrderModel> purchaseOrderList)
        {
            RHSettings.LoadConfig();
            ImportOrders(RHSettings.ConnectionString, purchaseOrderList);
        }

        /// <summary>
        /// Import orders to given valid RMH database connection
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="purchaseOrderList"></param>
        /// <returns></returns>
        public static void ImportOrders(string connectionString, IEnumerable<PurchaseOrderModel> purchaseOrderList)
        {
            using (SqlConnection con = new SqlConnection(RHSettings.ConnectionString))
            {
                con.Open();

                int nextPOID = int.Parse(DbHelper.ExecuteScalar(con, "SELECT Isnull(MAX(ID),0)+1 FROM [PurchaseOrder]"));
                int nextPOEntryID = int.Parse(DbHelper.ExecuteScalar(con, "SELECT Isnull(MAX(ID),0)+1 FROM [PurchaseOrderEntry]"));
                int nextPODID = int.Parse(DbHelper.ExecuteScalar(con, "SELECT Isnull(MAX(ID),0)+1 FROM [POD_Order]"));
                int nextPODEntryID = int.Parse(DbHelper.ExecuteScalar(con, "SELECT Isnull(MAX(ID),0)+1 FROM [POD_OrderEntry]"));

                SqlTransaction tran = con.BeginTransaction();

                foreach (var po in purchaseOrderList)
                {
                    po.ID = nextPOID;
                    po.Entries?.ForEach(poe =>
                    {
                        poe.PurchaseOrderID = nextPOID;
                        poe.ID = nextPOEntryID;
                        nextPOEntryID++;
                    });
                    nextPOID++;

                }

                Func<int, IEnumerable<PurchaseOrderEntryModel>, IEnumerable<POD_OrderEntryModel>> getPODEntires =
                    new Func<int, IEnumerable<PurchaseOrderEntryModel>, IEnumerable<POD_OrderEntryModel>>((orderID, poEntries) =>
                    {
                        return poEntries?.Select(x => new POD_OrderEntryModel()
                        {
                            ID = nextPODEntryID++,
                            RmsID = x.ID,
                            OrderID = orderID,
                            EntryType = 2,
                            EntryID = x.ItemID,
                            Description = x.ItemDescription,
                            OrderNumber = x.OrderNumber,
                            QtyReceived = x.QuantityReceivedToDate,
                            Quantity = x.QuantityOrdered,
                            StoreID = x.StoreID,
                            UnitCost = x.Price
                        }) ?? new POD_OrderEntryModel[0];
                    });

                var podOrders = purchaseOrderList.Select(p =>
                {
                    int orderID = nextPODID++;
                    return new POD_OrderModel()
                    {
                        ID = orderID,
                        PoType = p.POType,
                        RmsID = p.ID,
                        StoreID = p.StoreID,
                        DocType = p.POType,
                        Number = p.PONumber,
                        Status = p.Status == 2 ? 5 : p.Status,
                        DelStatus = p.Status == 2 ? 5 : 0,
                        SupplierID = p.SupplierID,
                        DateCreated = p.DateCreated,
                        OrderDate = p.DateCreated,
                        RequiredDate = p.RequiredDate ?? p.DateCreated,
                        AddrTo = p.To,
                        ShipTo = p.ShipTo,
                        Requisitioner = p.Requisitioner,
                        FOBPoint = p.FOBPoint,
                        Freight = p.Freight,
                        CurrencyID = p.CurrencyID,
                        ExchangeRate = p.ExchangeRate,
                        PayTermID = p.PayTermID,
                        ShipViaID = p.ShipViaID,
                        PurchaserID = p.PurchaserID,
                        Entries = new List<POD_OrderEntryModel>(getPODEntires(orderID, p.Entries).ToArray()),
                    };
                }).ToArray();

                var dataset = purchaseOrderList.ToDataSet();
                dataset.Tables["PurchaseOrder"].Columns.Remove("Entries");
                dataset.Tables["PurchaseOrder"].Columns.Remove("PayTermID");
                dataset.Tables["PurchaseOrder"].Columns.Remove("PurchaserID");
                dataset.Tables["PurchaseOrder"].Columns.Remove("ShipViaID");

                dataset.Tables.Add("PurchaseOrderEntry");
                foreach (var po in purchaseOrderList)
                {
                    if (po.Entries != null && po.Entries.Count > 0)
                        dataset.Tables["PurchaseOrderEntry"].Merge(po.Entries.ToDataSet().Tables[0]);

                }

                var dsPODOrder = podOrders.ToDataSet();
                dataset.Merge(dsPODOrder); //merge custom header table
                dataset.Tables["POD_Order"].Columns.Remove("Entries");

                dataset.Tables.Add("POD_OrderEntry");

                foreach (var pod in podOrders)
                {
                    if (pod.Entries != null && pod.Entries.Count > 0)
                        dataset.Tables["POD_OrderEntry"].Merge(pod.Entries.ToDataSet().Tables[0]);
                }

                try
                {
                    foreach (DataTable tbl in dataset.Tables)
                    {
                        SqlBulkCopy sbc = new SqlBulkCopy(con, SqlBulkCopyOptions.KeepIdentity, tran);
                        sbc.DestinationTableName = tbl.TableName;

                        foreach (DataColumn col in tbl.Columns)
                        {
                            sbc.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        }

                        sbc.WriteToServer(tbl);
                    }
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    if (tran != null)
                        tran.Rollback();

                    throw ex;
                }
            }
        }
        #endregion

        #region Utilities
        /// <summary>
        /// Prints the error.
        /// </summary>
        /// <param name="error">The error.</param>
        private static void PrintError(string error)
        {
            Console.WriteLine();
            Console.WriteLine("Error: " + error);

            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        /// <summary>
        /// Prints the error.
        /// </summary>
        /// <param name="ex">The ex.</param>
        private static void PrintError(Exception ex)
        {
            string error = ex.Message;
            while (ex.InnerException != null)
            {
                ex = ex.InnerException;
                error += "\r\n       " + ex.Message;
            }

            Program.PrintError(error);
        }
        #endregion

    }

}
