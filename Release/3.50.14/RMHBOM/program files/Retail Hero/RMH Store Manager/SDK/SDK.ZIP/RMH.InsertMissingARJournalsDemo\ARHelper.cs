﻿using RetailHero.POS.Core.Shared;
using RetailHero.POS.Core.Shared.Helpers;
using RetailHero.POS.Core.Shared.Utilities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.InsertMissingARJournals
{
    public class ARHelper
    {

        private const string sqlCreateARAuditEntry = @"INSERT INTO [AR_AuditEntry]([TimeStamp],[StoreID],[StoreUserID],[UserID])
        VALUES(GETDATE(),(Select [StoreID] FROM [Configuration]),0,0);
        SELECT IDENT_CURRENT('AR_AuditEntry');";
        private const string sqlGetMissingTxns = @"SELECT A.ID AS [AccountID],[TE].[TenderID],1 AS [DocumentType],
[T].[TransactionNumber] AS [DocumentID],[T].[Total] AS [Amount],[T].[BatchNumber],[T].[CashierID],
[T].[Time] AS [PostingDate],[T].[CustomerID],[T].[StoreID] FROM [Transaction] [T]
INNER JOIN [TenderEntry] [TE] ON [T].[TransactionNumber]=[TE].[TransactionNumber]
INNER JOIN [Tender] ON [TE].[TenderID]=[Tender].[ID]
INNER JOIN [AR_AccountLink] [AL] ON [AL].[LinkID]=[T].[CustomerID]
INNER JOIN [AR_Account] [A] ON [A].[ID]=[AL].[AccountID]
LEFT OUTER JOIN(SELECT [ART].ID,[ART].[DocumentID],[ART].[DocumentType],[ART].[CustomerID],[ART].[Amount],[ART].[PostedDate], [LE].[StoreID] FROM [AR_Transaction] [ART] 
INNER JOIN [AR_LedgerEntry] [LE] ON [ART].[ID]=[LE].[TransactionID]
) [ART] ON [T].[CUSTOMERID]=[ART].[CustomerID] AND [ART].[Amount] = [TE].[Amount]
AND (datediff(mi,[T].[Time],[ART].[PostedDate]) BETWEEN -2 and 2) AND [ART].[StoreID]=[T].[StoreID]
WHERE [T].[TIME]>=[A].[DateOpened] {0}
AND [Tender].[AdditionalDetailType]=4
AND ART.ID IS NULL
UNION ALL
SELECT A.ID AS [AccountID],[TE].[TenderID],
0 AS [DocumentType],
[T].[ID] AS [DocumentID],[T].[Amount] AS [Amount],[T].[BatchNumber],[T].[CashierID],
[T].[Time] AS [PostingDate],[T].[CustomerID],[T].[StoreID] FROM [Payment] [T]
INNER JOIN [TenderEntry] [TE] ON [T].[ID]=[TE].[PaymentID] AND [T].[StoreID]=[TE].[StoreID]
--INNER JOIN [Tender] ON [TE].[TenderID]=[Tender].[ID]
INNER JOIN [AR_AccountLink] [AL] ON [AL].[LinkID]=[T].[CustomerID]
INNER JOIN [AR_Account] [A] ON [A].[ID]=[AL].[AccountID]
LEFT OUTER JOIN(SELECT [ART].ID,[ART].[DocumentID],[ART].[DocumentType],[ART].[CustomerID],[ART].[Amount],[ART].[PostedDate], [LE].[StoreID] FROM [AR_Transaction] [ART] 
INNER JOIN [AR_LedgerEntry] [LE] ON [ART].[ID]=[LE].[TransactionID]) [ART] ON [T].[CUSTOMERID]=[ART].[CustomerID] AND [ART].[Amount] = [T].[Amount]
AND (datediff(mi,[T].[Time],[ART].[PostedDate]) BETWEEN -2 and 2) AND [ART].[StoreID]=[T].[StoreID] AND [ART].[DocumentType]=0
WHERE [T].[TIME]>=[A].[DateOpened] {0}
AND ART.ID IS NULL";

        private const string sqlInsertARTransaction = @"INSERT INTO [AR_Transaction] ([PostingDate],[CustomerID],[DocumentType],[DocumentID],[Amount],[Balance],[BatchNumber],[CashierID],
[TenderID],[Reference],[Status],[PostedDate],[UserID],[OrderID],[ReceivableID])VALUES(
@PostingDate,@CustomerID,@DocumentType,@DocumentID,@Amount,@Balance,@BatchNumber,@CashierID,
@TenderID,@Reference,@Status,@PostedDate,0,0,0)
SELECT IDENT_CURRENT('AR_Transaction')";

        private const string sqlInsertARLedgerEntry = @"INSERT INTO [AR_LedgerEntry]([AccountID],[CustomerID],
[StoreID],[LinkID],[LinkType],[AuditEntryID],[DocumentType],[DocumentID],[PostingDate],[DueDate],[LedgerType],
[Reference],[Description],[CurrencyID],[CurrencyFactor],[Positive],[TransactionID],[Comment],[ClosingDate],[ReasonID],
[HoldReasonID],[UndoReasonID],[PayMethodID],[LastUpdated])
VALUES(@AccountID,@CustomerID,@StoreID,@LinkID,@LinkType,@AuditEntryID,@DocumentType,@DocumentID,@PostingDate,
@DueDate,@LedgerType,@Reference,@Description,0,1,@Positive,@TransactionID,@Comment,@ClosingDate,
0,0,0,0,@LastUpdated)
SELECT IDENT_CURRENT('AR_LedgerEntry')";

        private const string sqlInsertARLedgerEntryDetail = @"INSERT INTO [AR_LedgerEntryDetail]([LedgerEntryID],
[LedgerType],[AccountID],[DueDate],[PostingDate],[DetailType],[Reference],[Amount],[AmountACY],[AmountLCY],
[AuditEntryID],[AppliedEntryID],[AppliedAmount],[UnapplyEntryID],[UnapplyReasonID])
VALUES(@LedgerEntryID,@LedgerType,@AccountID,@DueDate,@PostingDate,@DetailType,@Reference,@Amount,
@AmountACY,@AmountLCY,@AuditEntryID,0,0,0,0)";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AllJournals"></param>
        /// <param name="statDate"></param>
        /// <param name="EndDate"></param>
        public static async Task InsertMissingARJournalsAsync(bool AllJournals, DateTime? statDate = null, DateTime? EndDate = null)
        {
            if (AllJournals == false && statDate == null && EndDate == null)
            {
                ConsoleHelper.WriteHelp();
                return;
            }

            RHSettings.LoadConfig();
            int arAuditEntryID = 0;
            int arTranID = 0;
            int arLedgerEntryID = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(RHSettings.ConnectionString))
                {
                    await connection.OpenAsync();

                    var missingTxns = await GetAllMissingTransactionsAsync(connection, AllJournals, statDate, EndDate);
                    if (missingTxns?.Count() > 0)
                    {
                        Console.WriteLine("{0} missing AR Journals found", missingTxns.Count());
                        Console.WriteLine("{0} On Account Transactions", missingTxns.Count(x => x.DocumentType == 1));
                        Console.WriteLine("{0} Account Payments", missingTxns.Count(x => x.DocumentType == 0));
                        Console.WriteLine("Press 'y/Y to start restoring missing AR journals");
                        var key = Console.ReadKey();
                        if (key.Key.ToString().ToLower() != "y")
                            return;
                    }
                    else
                    {
                        Console.WriteLine("No missing AR journals found, press any key to quit...");
                        Console.ReadKey();
                        return;
                    }

                    Console.WriteLine();
                    // inserting to ar tables
                    using (SqlTransaction tran = connection.BeginTransaction())
                    {
                        SqlCommand cmdInsertARAuditEntry = new SqlCommand(sqlCreateARAuditEntry, connection, tran);
                        SqlCommand cmdInsertARTransaction = new SqlCommand(sqlInsertARTransaction, connection, tran);
                        SqlCommand cmdInsertARLedgerEntry = new SqlCommand(sqlInsertARLedgerEntry, connection, tran);
                        SqlCommand cmdInsertARLedgerEntryDetail = new SqlCommand(sqlInsertARLedgerEntryDetail, connection, tran);
                        foreach (var txn in missingTxns)
                        {
                            //create ar Audit entry
                            arAuditEntryID = Convert.ToInt32(await cmdInsertARAuditEntry.ExecuteScalarAsync());
                            //insert AR_Transaction table

                            cmdInsertARTransaction.Parameters.Clear();
                            cmdInsertARTransaction.Parameters.AddRange(GetParametersForARTransaction(txn));
                            arTranID = Convert.ToInt32(await cmdInsertARTransaction.ExecuteScalarAsync());
                            //////
                            // insert ar LedgerEntry
                            cmdInsertARLedgerEntry.Parameters.Clear();
                            cmdInsertARLedgerEntry.Parameters.AddRange(GetParametersForARLedgerEntry(arAuditEntryID, arTranID, txn));
                            arLedgerEntryID = Convert.ToInt32(await cmdInsertARLedgerEntry.ExecuteScalarAsync());
                            //insert ar ledger entry detail
                            cmdInsertARLedgerEntryDetail.Parameters.Clear();

                            cmdInsertARLedgerEntryDetail.Parameters.AddRange(GetParametersForARLedgerEntryDetail(
                            arAuditEntryID: arAuditEntryID, arledgerEntryID: arLedgerEntryID, txn: txn,
                            postingDate: txn.DocumentType == 0 ? DateTime.Now : txn.PostingDate,
                            ledgerType: (short)(txn.DocumentType == 0 ? 1 : 3)));
                            cmdInsertARLedgerEntryDetail.ExecuteNonQuery();
                        }

                        tran.Commit();

                        connection.Close();

                        Console.WriteLine("{0} missing AR Journals restored successfully,Press any key to exit.", missingTxns.Count());
                        Console.ReadKey();

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();

            }
        }

        private static SqlParameter[] GetParametersForARLedgerEntryDetail(int arAuditEntryID, int arledgerEntryID,
            AR_TransactionModel txn, DateTime postingDate, short ledgerType = 3, short detailType = 0)
        {
            decimal amount = txn.Amount;
            if (txn.DocumentType == 0) //payment
                amount *= -1;

            return new SqlParameter[]
            { new SqlParameter("@LedgerEntryID",arledgerEntryID),
            new SqlParameter("@LedgerType",ledgerType),
            new SqlParameter("@AccountID",txn.AccountID),
            new SqlParameter("@DueDate",DateTime.Now),
            new SqlParameter("@PostingDate",postingDate),
            new SqlParameter("@DetailType",System.Data.SqlDbType.SmallInt){Value=detailType },
            new SqlParameter("@Reference","TR:" + txn.DocumentID),
            new SqlParameter("@Amount", amount),
            new SqlParameter("@AmountACY",amount),
            new SqlParameter("@AmountLCY",amount),
            new SqlParameter("@AuditEntryID",arAuditEntryID)
            };
        }

        private static SqlParameter[] GetParametersForARLedgerEntry(int arAuditEntryID, int arTranID, AR_TransactionModel txn)
        {
            dynamic closingDate = DBNull.Value;
            if (txn.DocumentType == 0)//payment
                closingDate = DateTime.Now;

            return new SqlParameter[] {
                            new SqlParameter("@AccountID", txn.AccountID),
                            new SqlParameter("@CustomerID", txn.CustomerID),
                            new SqlParameter("@StoreID", txn.StoreID),
                            new SqlParameter("@LinkID", txn.CustomerID),
                            new SqlParameter("@LinkType", 1),
                            new SqlParameter("@AuditEntryID", arAuditEntryID),
                            new SqlParameter("@DocumentType",txn.DocumentType==0?1: 3),
                            new SqlParameter("@DocumentID", txn.DocumentID),
                            new SqlParameter("@PostingDate", txn.PostingDate.Date),
                            new SqlParameter("@DueDate", DateTime.Now),
                            new SqlParameter("@LedgerType",txn.DocumentType==0?1: 3),
                            new SqlParameter("@Reference", "TR:" + txn.DocumentID.ToString()),
                            new SqlParameter("@Description", String.Format("Missing {0} from batch:{1}",(txn.DocumentType==0 ?"Pymt":"Txn")  , txn.BatchNumber)),
                            new SqlParameter("@Positive",txn.DocumentType==0? 0: 1),
                            new SqlParameter("@TransactionID", arTranID),
                            new SqlParameter("@Comment", String.Format("Missing {0} from batch:{1}",(txn.DocumentType==0 ?"Pymt":"Txn")  , txn.BatchNumber)),
                            new SqlParameter("@ClosingDate", closingDate),
                            new SqlParameter("@LastUpdated", DateTime.Now)
                        };
        }

        private static SqlParameter[] GetParametersForARTransaction(AR_TransactionModel txn)
        {
            return new SqlParameter[] {
                        new SqlParameter("@PostingDate",txn.PostingDate.Date),
                        new SqlParameter("@CustomerID",txn.CustomerID),
                        new SqlParameter("@DocumentType",txn.DocumentType ),
                        new SqlParameter("@DocumentID",txn.DocumentID),
                        new SqlParameter("@Amount",txn.Amount),
                        new SqlParameter("@Balance",txn.Amount),
                        new SqlParameter("@BatchNumber",txn.BatchNumber),
                        new SqlParameter("@CashierID",txn.CashierID),
                        new SqlParameter("@TenderID",txn.TenderID),
                        new SqlParameter("@Reference","TR:"+ txn.DocumentID),
                        new SqlParameter("@Status",2),
                        new SqlParameter("@PostedDate",txn.PostingDate)

                        };
        }

        private static async Task<IEnumerable<AR_TransactionModel>> GetAllMissingTransactionsAsync(SqlConnection connection,
            bool AllJournals, DateTime? statDate = null, DateTime? EndDate = null)
        {
            string filtrEpr = String.Empty;

            List<SqlParameter> parameters = new List<SqlParameter>();
            Console.WriteLine("Insert Missingg AR Journals..");
            Console.WriteLine("\r\n--Note: Taking a databass backup is recommended before performing this repair.--");
            if (AllJournals)
                Console.WriteLine("Retriving all missing AR Journals");
            else
            {
                if (statDate.HasValue && EndDate.HasValue)
                {
                    filtrEpr = " AND CONVERT(DATE, [T].[Time]) BETWEEN CONVERT(DATE, @f1) AND CONVERT(DATE, @f2) ";
                    parameters.AddRange(new SqlParameter[]
                    {
                                new SqlParameter("@f1",statDate.Value),
                                new SqlParameter("@f2",EndDate.Value)
                    });
                    Console.WriteLine(String.Format("Retriving all missing AR Journals between {0} And {1}", statDate.Value, EndDate.Value));
                }
                else
                {
                    if (statDate.HasValue)
                    {
                        filtrEpr = " AND CONVERT(DATE,[T].[Time])>= CONVERT(DATE, @f1) ";
                        parameters.Add(new SqlParameter("@f1", statDate.Value));

                        Console.WriteLine(String.Format("Retriving all missing AR Journals From {0}", statDate.Value));
                    }
                    else if (EndDate.HasValue)
                    {
                        filtrEpr = " AND CONVERT(DATE, [T].[Time]) <= CONVERT(DATE, @f1)";
                        parameters.Add(new SqlParameter("@f1", EndDate.Value));
                        Console.WriteLine(String.Format("Retriving all missing AR Journals upto {0}", EndDate.Value));
                    }
                }
            }

            //DataMapping.Map()
            SqlCommand cmd = new SqlCommand(String.Format(sqlGetMissingTxns, filtrEpr), connection);
            if (parameters.Count > 0)
                cmd.Parameters.AddRange(parameters.ToArray());

            using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
            {
                var missingTxns = DataMapping.Map<AR_TransactionModel>(rdr);
                rdr.Close();
                return missingTxns;
            }
        }


    }

}
