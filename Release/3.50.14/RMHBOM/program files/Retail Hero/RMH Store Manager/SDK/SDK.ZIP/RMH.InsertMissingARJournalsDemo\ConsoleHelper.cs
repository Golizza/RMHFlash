﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.InsertMissingARJournals
{
    public class ConsoleHelper
    {
        public static void WriteHelp()
        {
            Console.WriteLine("Insert Missingg AR Journals [/fromdate:<fromdate>] [/todate:<todate>] [/all|/a]");
            Console.WriteLine("--Note:Taking a databass backup is recommended before performing this repair.--");
            Console.WriteLine(" - fromdate/ todate : must be in Universal sortable date format: yyyy-MM-dd");
            Console.WriteLine(" - fromdate         : optional,\r\n must be smaller or equal ToDate when toDate is specified\r\n When toDate is not specified system will consider toDate as current time");
            Console.WriteLine(" - todate           : optional, must be greater or equal ToDate when fromDate is also specified.\r\n When FromDate is not specified system will consider all records upto <todate> value");
            Console.WriteLine("/all|/a ignores fromdate /todate.");
            Console.ReadKey();
        }

    }
}
