﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.InsertMissingARJournals
{
    public class AR_TransactionModel
    {
        public int DocumentID { get; set; }
        public short DocumentType { get; set; }
        public int CustomerID { get; set; }
        public int StoreID { get; set; }
        public int AccountID { get; set; }
        public int AuditEntryID { get; set; }
        public decimal Amount { get; set; }
        public DateTime PostingDate { get; set; }
        public int BatchNumber { get; set; }
        public int CashierID { get; set; }
        public int TenderID { get; set; }
    }
}
