﻿using RMH.InsertMissingARJournals;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RMH.InsertMissingARJournalsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                ConsoleHelper.WriteHelp();
                return;
            }

            Dictionary<string, string> commandLineArgs = new Dictionary<string, string>();
            string currentArg = String.Empty;
            string[] definedArgs = new string[] { "/fromdate:", "/todate:", "/all" };

            string argValue = null;
            foreach (var arg in args)
            {
                var commandLineArg = definedArgs.FirstOrDefault(xarg => arg.StartsWith(xarg, StringComparison.OrdinalIgnoreCase));

                if (commandLineArg != null)
                {
                    currentArg = commandLineArg;
                    argValue = arg.Substring(commandLineArg.Length);
                    commandLineArgs[commandLineArg] = argValue;
                }
                else
                {
                    if (currentArg != null)
                        commandLineArgs[currentArg] += commandLineArgs[currentArg] + arg.Trim();
                }

            }

            // Parse parameters
            DateTime fromDate = DateTime.MinValue;
            DateTime toDate = DateTime.MinValue;
            if (commandLineArgs.ContainsKey("/fromdate:"))
                if (!DateTime.TryParseExact(commandLineArgs["/fromdate:"], "yyyy-MM-dd", Thread.CurrentThread.CurrentCulture, System.Globalization.DateTimeStyles.None, out fromDate))
                    ConsoleHelper.WriteHelp();

            if (commandLineArgs.ContainsKey("/todate:"))
                if (!DateTime.TryParseExact(commandLineArgs["/todate:"], "yyyy-MM-dd", Thread.CurrentThread.CurrentCulture, System.Globalization.DateTimeStyles.None, out toDate))
                    ConsoleHelper.WriteHelp();

            if (fromDate != DateTime.MinValue && toDate != DateTime.MinValue && fromDate > toDate)
            {
                ConsoleHelper.WriteHelp();
            }

            Task.Run(async () => await ARHelper.InsertMissingARJournalsAsync(commandLineArgs.ContainsKey("/all"), 
                (fromDate== DateTime.MinValue? null: fromDate as DateTime?),
                (toDate==DateTime.MinValue ? null: toDate as DateTime?))).GetAwaiter().GetResult();
        }

    }
}
