﻿
using RMH.APP.Core.Shared;
using RMH.APP.Core.Shared.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMH.OrderExtensionDemo
{
    [Export(typeof(IRMHCustomExtension))]
    public class Order : IRMHCustomExtension
    {
        public ApplicationSession AppSession { get; set; }

        public Order()
        {
            ServiceProvider service = ServiceProvider.Instance;

            AppSession = (ApplicationSession)service.GetObject(typeof(ApplicationSession));

            //register for getting notification when Order object is saved
            AppSession.onOrderSavedBefore += AppSession_onOrderSavedBefore;
            AppSession.onOrderSavedAfter += AppSession_onOrderSaved;
            AppSession.onOrderPostCompletedBefore += AppSession_onOrderPostCompletedBefore;
            AppSession.onOrderPostCancelled += AppSession_onOrderPostCancelled;
        }

        private void AppSession_onOrderPostCancelled()
        {
            MessageBox.Show("Order Post Events:\n\t onOrderPostCancelled", "RMH.OrderExtensionDemo");
        }

        private void AppSession_onOrderPostCompletedBefore(IPurchaseOrder arg1, System.ComponentModel.CancelEventArgs arg2)
        {
            if (MessageBox.Show("Do you want to cancel order completion?", "RMH.OrderExtensionDemo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                arg2.Cancel = true;
            }
        }

        private void AppSession_onOrderSaved(IPurchaseOrder obj)
        {

        }

        private void AppSession_onOrderSavedBefore(IPurchaseOrder arg1, System.ComponentModel.CancelEventArgs arg2)
        {

        }



    }
}
