﻿using RMH.APP.Core.Shared;
using RMH.APP.Core.Shared.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMH.PostClosedBatchesExtensionDemo
{
    [Export(typeof(IRMHCustomExtension))]
    public class PostClosedBatchesExtensionDemo :IRMHCustomExtension
    {
        public ApplicationSession AppSession { get; set; }

        public PostClosedBatchesExtensionDemo()
        {
            ServiceProvider service = ServiceProvider.Instance;

            AppSession = (ApplicationSession)service.GetObject(typeof(ApplicationSession));

            // register for getting notifications when closed batches are posted
             AppSession.onCompletedPostingClosedBatches += AppSession_onCompletedPostingClosedBatches;
        }
        /// <summary>
        /// arg1,batches being exported
        /// arg2- exported xml/csv
        /// </summary>
        /// <param name="arg1"></param>
        /// <param name="arg2"></param>
        private void AppSession_onCompletedPostingClosedBatches(IBatchModel[] arg1, string arg2)
        {
            
        }

      
    }
}
