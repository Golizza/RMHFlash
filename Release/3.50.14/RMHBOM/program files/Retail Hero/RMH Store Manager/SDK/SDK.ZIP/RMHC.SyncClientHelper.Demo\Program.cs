﻿namespace RMHC.SyncClientHelper.Demo
{
    using System;
    using RMH.SyncClientHelper;

    /// <summary>
    /// The main program class.
    /// </summary>
    public class Program
    {
        // The connection string. With empty string, Sync Client Helper will use the default one in RH Settings.
        private static string connectionString = string.Empty;

        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {

            if (args.Length > 0)
            {
                string command = args[0].ToLower().Trim();
                if (args.Length != 2)
                {
                    return;
                }
                try
                {
                    switch (command)
                    {
                        case "purchaseorder":
                            // The PO Number need to sync to Cenrtal.
                            string poNumber = args[1];
                            SyncPurchaseOrder(poNumber);
                            break;
                        case "transferin":
                            string tiNumber = args[1];
                            SyncTransferOrder(tiNumber, 2);
                            break;
                        case "transferout":
                            string toNumber = args[1];
                            SyncTransferOrder(toNumber, 3);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Exception occurs: {ex}");
                }
            }
            else
            {
                Console.WriteLine("Supported demo commands:");
                Console.WriteLine($" - SyncClientHelperDemo PurchaseOrder <PO Number> ");
                Console.WriteLine($" - SyncClientHelperDemo TransferIn <TO Number> ");
                Console.WriteLine($" - SyncClientHelperDemo TransferOut <TO Number> ");

            }


            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        /// <summary>
        /// Synchronizes the purchase order.
        /// </summary>
        /// <param name="poNumber">The purchase order number.</param>
        private static void SyncPurchaseOrder(string poNumber)
        {
            Console.WriteLine($"Start synching Purchase Order {poNumber} and its dependencies.");
            Console.WriteLine();

            using (SyncClientHelper helper = new SyncClientHelper(connectionString))
            {
                helper.SyncPurchaseOrder(poNumber).GetAwaiter().GetResult();
            }


            Console.WriteLine("Done. The Business Object is already added to the holder and waiting to sync to Central.");

        }

        /// <summary>
        /// Synchronizes the transfer order.
        /// </summary>
        /// <param name="transferNumber">The transfer order number</param>
        /// <param name="orderType">The order type </param>
        private static void SyncTransferOrder(string transferNumber, int orderType)
        {
            Console.WriteLine($"Start synching Transfer Order {transferNumber} and its dependencies.");
            Console.WriteLine();

            using (SyncClientHelper helper = new SyncClientHelper(connectionString))
            {
                helper.SyncTransferOrder(transferNumber, orderType).GetAwaiter().GetResult();
            }


            Console.WriteLine("Done. The Business Object is already added to the holder and waiting to sync to Central and other Store.");

        }
    }
}
