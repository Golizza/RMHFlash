﻿using RetailHero.POS.Core.Shared;
using RetailHero.POS.Core.Shared.ZipArchive;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Read_RMH_Receipt_Data
{
    class Program
    {
        static void Main(string[] args)
        {
            var sampleReceiptData = "leqbGFDjRyVnM5V3ZZEsIpw6jNs3Ysfz+/U2gXW+GCXnffH+kBmyTMxSKRcsoS0QoZpoOs1sTd/Kp3Q3EQ4EM1UGsv5gV3Yoj4gladRB9hcWXcB1VFo7DbE+UcinHK3IxunKx2LcWHD9hh66UAPm3hCFg8E0NQzCvxtP60dVpICNcp+9JhCWowtdYTNtawT0LshL5myLr0oC4icJHrZulyYrDM/LKBTNlTt3OLogefKNM85xYVzgMYfrh3PJxlnWuTFaf6iHLvX5wIjC0NYUn3vArBahX8evAAT2rzplHXgzVf61RPLTg0wFEeigyhEYMn+0KWas6sGguBLHlA8j6tAQoMszeCkRpVZSA8EzjTbkLqBClN9huq2cIludS75NuAPUc5Id54lp51wksoXh05UlxtIjKMe7UyglNBTMmUKEHOXoXRdnvgqsv5BTDBlhutZArLfQ91IOHGYv/+b8xgtKda4m9BCTydNF+ZGCl15utr9mFeIsDWVtukhdQQ71RTF7QMy56Z2s8qo0YMGTjd6sphLLG9MSqYKxeNNzx1L/ODYuEo0oP6lIPT16SJuLIfrVkvDRJ+TtwsiACW/JvE/37Fw9YP9xbUuG2uoQnR7iMAgljzzuChUGrwzLClkl387mHfW760SeHiibMJ7HNHL/t3pW5ibfwjadv4BSl4ZWI7aYLWCzRlW4ePwINhgyqiyV+8QEiYoZ2/cfOkuztCaw4M+gOI7zeBN1LdIQyke2j1RMK/e0ejWc4eibCDKC0eWaHvzmKFEwVdjUWeahHKg4j8J9bMCD0F8HIW0JTwDpPhG/B0c+geRrdZFg52wmAG9MgsEqWNGjaf/MYq7lucxfqb1ELa69OAnfSbEmNEmLaBMkST7FMDUqALgwbsesfpDl2ZFlJ/YyE9IBwSmuMwLHy73M7TXMYpVXhhIssIWVRGwyBKAWW3vDqb/28YffU59oUz+cy8g50gXpCd9HDgsofVzpG9QFO6TCb78M6unQm8ySkqngs7bA7DfuLZSSS4szQkvvuVF8Cl6r2B/NzaCZ8iVxoGVWQ0HElvlMpi2zk9VWjPh/0OmC0om5qUasWK4PBymYOV0OVnXkkPFYPHHcdPkLDmZRUIfdM5oOi6Wl3+LkgoX9DvHx0WpoBWdU7X9AVehLQcRj+jWZ0f9udpQMzwdKgx+5V4wid9uRoYqMUO9cchJiri38+hWNL5M9Qa+7cX9wsA99HwOvwjIfEPAi2QFEaj+rroQaQYe02J6LzmGYP5BDh7pVMJxLu/jjDevzv5za7dkRjdgylhwJbxMLNfH5UG63SXn7r+l1M7FAkUYmiHmJH+65ji4DPaERgH2sNFwwTv3V3PG0GvKRXporWuzliqzegveeZJhEu5V+FAE0PsliwXmba7onRbg9G6PKlDMYbKqHKO8b8mhd7J2v0bl3tZYRI90upil43972wP6bYfYrxS+L9lZ8ZjfORLjT1U+8BO8lYURZbHiJ4+FyfRZG/myumOTV8mpfwv6iRrLpSwjXn51p8zYLxUQ9Wj+VWR91keoXQ+JhGkrmgGuzxve3j/DcDl9Cow32hdT0x4Kdev9VwnWvZHQqHZx8B1p/7wdgnt7JMGMMxpP8gQL4Y71Q2GM4AUc1v/SIWiE1TsZ3iBraDUtOmmcqNlJ6CdByWzREOQ1sP2oXAfdM0yYrHvCvLL2HCtc94ltfghF1tBkpTw7z0c7YZbLA2GJ2ICe7eHYYLv5KBEWLEzlZnMHXG0iddHSp9+IVNb/crTniONYgaZpCxaLcFx+0wVVZgehT2s+nLFtBun8xO+ZtrCbnBg5WbJEZBIWfA9/m4d5dChkfW6RHSBuId7RVCf7Ff2y7Ym5VMLlOZostR/RFxpmCoQ71BzDc3H3Ebv3xR88m7w+pBlq3gy1/CIldWyrU/cElOmzDz3pD6dxzQ8DDTFvRuWpsJxGGxGeZIzY3E4NMs907XNwEwT5YdaiRhLWHUoMwVNM1BotL62xDvEnTTQiIayPaunCWo9OVAGfyEO1JQtdMsiTI4EksBLGYO+pJ3+70pnQnHFrNV6/p6z0aIkqh/1GbnPH2TZTYkOzT15hbMUxSYT9oCcq+CI2EGHhM6VAd+nIJz6pw3wEu2Sep9MwRtleGj3Mi6d8LCgy+WvyQ3JU4SxS5Rh+lv3LY+SBMDOzSVeNUjLUx59w/mssJ8CE7iFblUXLgYYbCXsfLxzok9j7sL80Ug0RctOxSp2KRRB4db4KNQPAMLAMEhQn904cNhxZ5mrpJSusgjPL9SAQKuQaMa+bYdFW8HZ6YrfIH2PIlvYMdgfV76oaMDsvUiDATN+hsv3nlrcHuVL+OAKCD5320cI/JV16X2m1gwUpPm78R6269OmNAbitV5sBswdicUdiYmRgkufgdvLjEwm8idJ/gsa+6Tp2Y4tP02oEuBuE8+Bwf0Vz0MVHMV4G4TfR9CD+PIqYqkrcyIuKMvw5K6cEeW3tl8YXYvM6M2U8ygoZZzUFRyZsDT+uVMKHb2oIc4xsUNqHzUDSjXu0NGeOZMJWX46r7q9lhGpj7n+rmp/6kzlpgEPd20/+8ZFvXBngoFEMK95+YRmQcIBrgHKUuZnAwFXcMn1UMMYCRx7jI5ZX4nXM4975op0Ifau6K71sTSJne4A1/tH8jP/Jw9Usu5e4W1DoosbPGseYDc3A0kfrr8zDMYsK2y0ixsc5leXWG3sn6u/LLp/p2qaGI8SZuYICNsxJ9DDKOHsjI7ExfvdXfz5LKm5+uev1siF/imtDTLLOmSamluPaxe4I8IB11S5nsIMu2J070tjZ+k5MvADz5scFH0mckNc6mOZzPppKT41p66i8ZIlXuwehdmvQ2NgnpRBZXSKOifSZfuhe02A8cHT3er1P8wCtDa8/35xVlUZTU82Bk9TiKukanp4ZZ4SaySS1xTT2hXf5nxKngEhd+YozWRxk4mvXs2asm4fF1WPafLL3lJN8gu96oztfA3Sq0cO/3FJzA4fu5gZWQfQ6F/TddxZr7a9tLLA4BrkhvxDc1ZIrcYgUBroltH48fLrep62rq7YloKp85VnOJblOOvDy2Bk/R6WR5001oAZXg2SsN1SWHOY83Y8N9peYRaMTNdS4ay+MAoXcfcan6vM/K5jwR9Ui0fCTI7Xa676FS7MCqzh3MgntiUsOcU+1amkIX7awm81CLkkmEsQYVDNqu2TCTX71cMydhCo53ulwuZzyVxtXx2Lq1jR8DsJC+X0cdnSm2aIg7EFz/ZEQLO2GXfHijr6ZbQbnvTSE42Z4Gs1dqQLdXQkSQBInTSvNm9RA2h2ex7sbPEniesKe+Ldl3Yya//g59wqAOf04gUSlQHeMe4lr5EWCNCzWFjdAVx/rISuhtQBfLH6iOAg3xMSmjGwYNTIxbf3PIbO8IJMIyGyvIKxCHVpa2jHeVVcVGWn7o6ozNoLqW7FFCg6HUuRNw8ACL4jgvx+HgFWSTIRCedsMaVW5fIzn01+hsD8+hAYjL9n5KbZ9zlS1Q4RwxReXP8f11gu36g2oANCiNz9ppKzTgQ4oQjaZa3QSVe8Nwz8Uv4YUKWMyxtsDkq9lYXwHHBaZLSUZckYLpOKND6qPPg16NmMewjoOD4NaI966G5oPJzYcXlP4/YcM2LNAc4xRp1KwnrJ30bTWkrys8d0+wICB5ZVW5xEx4AYM1k7ugrDaRuGNGn117cjxl7WFjaIF7vInqOp6tmhm3t8yYINEElfCrD2/P06RUq66MwgLd3K5NMDxXQeQU+XB9IrY4xA+Lfe0PqL9N38x/jyJJaFxeWV09cr20e+rpkCaw6yIobid4ed28RuxooDrR8yn3/VvntuqAfmXYsYWmPlKyGlq3TVZbdUSlMsvIuw0vfWVQN4nBPUFsGvuo7sZQQT2+Z/lNwYE/I0LXu/ML8ZDgUqUCimv3LbvEsCYI8tpQHONOzbgGiJv/H0T+Q6rkXqanHylKlRT7AfYoUPIYGuXGVFdSdpwETJGX3F+AjuJ1EOh/3B3kIP4+gldZwWmlJHI7kaTAevctvflL2xwaDLY3XOx1lDJHxiiCMJSsVKDuu+ZruBO6X/yACe3QpusdAQ1LpyoGlmb453Ki1o1fYj+dZuuGSD/E4UJCQxGN+KpoGTZQqDo5lTz2dGgBQIcu3yrQceVz6E9OEK9Y2+NF+8vnErH4+k6ju6icMP+zWGUqqnMExOtr558LVbnaoBot8oy60YeF68fb2JyBrLAfYf1I1aTHvhSooDWtgIHYg4m1CI2qizLEtcBxwYeRkH7AHK7pMf7fbPWhWTCQnO+uQFXO3OV+iY673ZZXfC9R6CNton1MWiIvvD3TC/zr9W/9MXOiJJPD6Mj2Pttw4WiQctyD5hnkQF/Bp5s2gfow46bWw6FywuxWpCTLlTwUwm6Ve0dAcEQEayHiOPHVrKPockgZ0PD3NHPoOl90F57HLpilpPPMsJN9FHnhESiYVzPe/EgPPxEFimq0zgB7pSVYTsLY7yiTEredHbib/cLdq8OXa5PiBdIEiP4OuY6eXsJu7iT2aadggcUsSfzH1DwXKVqfkpPmPOapE4gzFEqfqFBiQSgo7dtHks7YC+wRgmL08zZspxA+1HB36OlG0fvC+AXYKo7OwSWGu2emAaWtwji/qiXlH4b+nenHRvN9JyOfbBXK5Y7ISZ1caZgezxEzaUkCYOfhYfaCzAEs75+8GQYXglDqQWMROfuigSzZgjwmxLTnjOHe9jY6V352oOHo1dfS8hmX0Y62l0YM+tvsGbdeNYFWYlJZD8USm5UzgcYznGvQfM/LxjPV0hZvu4bFpPCxUOXDLHdCAglfwYhgT2ny8Quso9qCuSt6/nvg/Pi70gOJSFDVQb1P4jt4lex43Sk5r5pYaO2t5VZXE7pTNLGxj2biwAAoIKJt2QjTL97m8xDJ57rt0OSZ28msQO4zfi23HJqvtwiMkcChOSGrHZKVoZGgby2PTe8+w2ETySH7/ury4Qs0a/v3UeDzEQ1NhxFvtd5osT2w+egbvAPIsBB97OgBNgrOqZs5JniQrxap+tqJJy76JyGFuaD5RJ0SQLM1uCPyI4nXzoVc+Qxy5fhKftb5rLfFl0SNTAov8jCXDQKWxaQ1xbi7hK33vzed0pGJ7sxmsulyMfM69On3rRIzzCdU3aYuUZ0/hLR+Jh45Nj3hV8RrbItJ0SN+gc0Dxk9Z9c7X2kc77p0umd2pyL6woileiiG2wERM/CkwvmoqHhmy3F1f75OXBexX5xn+o0VyOL2fa+NdhwOv7Bi7gunLd75J0THf/+df9Jw1ol5qumpfPgvZ2pjf+GZvdGboYUtJXoQ1bZ2wn+P99Oia307YIqLkTeFLkNyN6KqO5px2TvntS4bg/1H7fdRtbZjvZ7GRlZD74i/31GJrLDMqAt9khoSUw45drUuO0vSauQNWYsk7Sr4s+sxzsnzcTSlB0N3i1tuPAourokIJ0kI4siUiqtrK82jPwqkPoHOJulwW+vpUyEnxDYD7yzx6c4zJLFd/b4uMmR81L+KekcWqUZ0su3papceYLdydXUPPL52rGUCPMVZnO0hwdmJrKyw0WsHbRF/5yS3XFC5/lxtj40fDUZS/7wmaMAY+FeOhBlijCh7FV3s+/4JnB/bRF55bc1mW6tqVJmn826lC8SogE2RLe/4YpNOIu1uMV2+Wc7NSFPUqcNPRtSl/JPx4wqpv1Q9xtn7/42xUQTAPfYpsqlH+q11bQFgiq4WJTbBtUFUuw1VzguGA6lkr1sQC4q0XVIWfDSVCABJsV+ZbjoMRXY22YWmdbst+NjDUOSSNlghEbzOdkEOh7TzHTeT5rxyye6+G8s0S0fgHl+iCetRD5oxFM/lX81ICK1tRih1mIgBzjvYKwV65AXePYw8FRHvY78iPexVi//bMmt3N8zmGcodDr61aWiCo/IJTdhnt2xDANc+PtsPKeHRBGsAtJYcgqeHTMU5AenG+N2hlumaE6xZZxdJgGQ1+UQKwDle635PBGP55GOq/FE0gjuWPQWnEuTEyoQyET2zJza2WE5mvjw1F5fYa8ZjSvpLHEVvT0rpZUJ1g442YpN22rT0ITq1T0Tf5P0k6Tfib89ZqNVDXHDU2RofT9KopIkTUmElnFspNbLSjsSm1ZPYw7aBSJjc7vxWzUxZKpGFnmr++77pIcxAKHJPOSZXU8h0ygBbKYDvmx4K5rxxGGwV1JPyaavOJcVDFOSVLFIqZ2Vbqpf5itImNat3JmSb410nHFTztdllpDqiqtX2HXttELpZsiztPO55NcbENzrE7yE+JWS1n600SPsitby1LCYx1psswkAL2Eq8nVfXtrbK/YczxgX5v1ZL2BG/Cm2jOxNPhN9dyxo4G2EzQPToyy5LUGfWqDSN0S9JiC7e1QbQu3+pMzSxc9YmhnndYtPsSmjEecdBF9uheDnhS18GROw6zqsGLWvaCnMyU6wJFeECN+BiNntB8jFAgvrvp2zvoNGxkPFoYl7SWbqQyej7xKgV39gnCU+B6/uKdIl/Lyg4dlONxhH18u2FRYPnhsTdaF9hvSwyayj38/zrkcupocsK3OLY3QNNdrDf624CvAX58ceM+xlB9KSLf2QBuD89FivVuvWIfam1T9/K6dr+Ua9EE3K6LCEAuu01EwugmmlE7TQ3LYrN3jEmN7LN3OHGYiF+mzrlvKIdTh7ZX3MrGHtPanWSpHot6qVaILp35T907IG1t82hSaIwMDehtSLjQAS7520ExEwmEX1ZghQ5IHhmbLq9r4qwL8GKThHBtHbkROOCk02iKg7bHw87rLdoM1Y63hvr6bw2b2qWoczLONk1n/IpITBSgsvjX8k5tr1xYw+9l48SweZ3jnXYpS+Ee9iPuVnpQpVNvcvL61QYFwsjK87crishPgMaRd1k8PDzv3c3YNBvGgaIPxYKyfu50tvFaV/TzIF+1BfgBeIFmucY5w2ZFauANNHkhLJLSkfEHMo9IYf9EN/L14tab2acJnFb7O1AcJcQLhB3GVKRud+NKGd12XPQJS6P+RSUfVVG/lPvw3MHoWzVD6FLeBTeC+1Jq21upzOKj66pYX6FOTDffC1YnJybREpqMhve3OTkakuik8F5tx4ewX2Ryb6MCMjVPtlMwvA9noMUYgB6j+6EkZ/aYAc6xEmRgRkpNEquJcBVcG0d05n3lMgdqCE89WtKzG1THLFJUk8+/C6VDo2+j9nFhth5+YPdaH5y8lQIrDbadfeeDOA/kPGd3xreNfm9EEo8yqIuIDA1I52+zel9byE0JIqiwBbG81x7gMITGGdW58vU0asvBegRNJlD3xjEZn1LslcElnznEJQjGCRMv+f2PsP79YPVA6cD/Vm5jXi/XpY2paNqUlfK2Ae0cnHnZeJvFa7fGoNY/Ljrta3ztBLrR1+IRjPbhR2wU+YFQ3dDQpDWnlk5V08dxh3pmKRSaFEaIep46EeobFr4wOwI1szZRQm/eQnUfHq5ggDmu9xs6cNrseuyK4ja609YUQ7MXYdRenwSLnVGkgSLP4Ys33UPNz7CDIE2rqfXBpQ0IMg2mtujf6WZM8Gz5qp/Ju3QsTGKUIEMW0CHbr1RjB7q+LbMd3GIQtVYwrGZ+H2bStVwxNxHz2GPnCbcn8QlTTl41zwVIZXd8VB+NVTTXoFtGN2VUDRBpTIULIQgrkmLYhkK2LYHBD66qD6EUkZoWPlERweZSxA33tPvDWueycjLA5iC8ApiaA/XTEHtLYY8Z8LcSFmlyHfURqQb/9LpapOz1eo0QZbq1hwVq+n2hKdBKEUbJSa5a21irc8wDURRiFw49iiYKJW9UoV7s2kssaloobrI6L2H2h990c6lRjE+/XQ4BN6jIZzOsVyfLoMUGAMVtrksY5NwLP9em5u7DUkVMa0N8i7jOX72FkKUkPeSupTRBYAhMPtpV4MUJLU4i6/Og2QPL3PQFktJVWGt48EacfxXRmVWDkZIoq+Ohb8qGZNq3a5UxL8wienDPAmFEkLFtPUBAZmf2xxkClSt8+bxsRb5zzYXuNmk=";
            Program program = new Program();
            Console.WriteLine(program.DecryptReceipt(sampleReceiptData));
            Console.ReadLine();
        }


        string DecryptReceipt(string receiptText)
        {
            string decryptXmlJournal = String.Empty;

            if (ZipArchive.IsCompressed(receiptText))
            {
                string decompress = ZipArchive.Decompress(receiptText);

                if (IsEncrypted(decompress))    
                {
                    decryptXmlJournal = Cryptographer.Decrypt(decompress.Replace("!=!enc!=!", string.Empty));
                }
            }
            else
            {
                try
                {
                    decryptXmlJournal = Cryptographer.Decrypt(receiptText);
                    decryptXmlJournal = ZipArchive.Decompress(decryptXmlJournal);
                }
                catch (Exception ex)
                {
                }
            }
            return decryptXmlJournal;
        }

        private  bool IsEncrypted(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            return text.StartsWith("!=!enc!=!", StringComparison.InvariantCulture);
        }

    }
}
